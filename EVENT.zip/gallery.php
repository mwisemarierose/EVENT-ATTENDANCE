<?php
$conn= mysqli_connect('localhost','rose','ikinyogote','event attendance');
//check for connection
if(!$conn){
    echo 'connection error:'. mysqli_connect_error();

}
else{
    echo '';
}
?>
<?php
$sql='SELECT eventname,filenames FROM gallery';

//$sql= mysql_query("SELECT id,fname,lname,email,sex,age,created_at FROM  users", $conn);
//query for result
$result=mysqli_query($conn,$sql);
//query to fetch results
$dsply=mysqli_fetch_all($result,MYSQLI_ASSOC) or trigger_error($conn->error);
//$dsply=$conn->query($sql) or trigger_error($conn->error);
//print_r($login);

?>

<!DOCTYPE html>
<html>
<head>
<title>Event | Gallery
</title>
<link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <nav class="nav-menu">
          <ul >
            <li><a href="home.php">Home</a></li>
          
            <li><a href="contact.php">Contact</a></li>
            <li><a href="gallery.php">Gallery</a></li>
            <li><a href="login.php">LOGIN</a></li>
          </ul>
        </nav>
      </header>
      <section>
<P><b>this page contains all photos taken during the event</b></p>
    <img src="image/PIC.JPG" width="300" height="300">
    <img src="download.jpeg" width="300" height="300">
    <img src="download.jpeg" width="300" height="300">
    <img src="download.jpeg" width="300" height="300">
</section>
</body>
</html>