<?php
$conn= mysqli_connect('localhost','rose','ikinyogote','event attendance');
//check for connection
if(!$conn){
    echo 'connection error:'. mysqli_connect_error();

}
else{
  
}
?>

<?php

//insert item data
// upload image

     if(isset($_FILES['image'])){
        $errors= array();
        $file_name = $_FILES['image']['name'];
        $file_size =$_FILES['image']['size'];
        $file_tmp =$_FILES['image']['tmp_name'];
        $file_type=$_FILES['image']['type'];
        $tmp=explode('.',$_FILES['image']['name']);
        $file_ext = end($tmp);
        
        $extensions= array("jpeg","jpg","png");
        
        if(in_array($file_ext,$extensions)=== false){
           $errors[]="extension not allowed, please choose a JPEG or PNG file.";
        }
        
        if($file_size > 2097152){
           $errors[]='File size must be excately 2 MB';
        }
        
        if(empty($errors)==true){
           move_uploaded_file($file_tmp,"images/".$file_name);
           $names="images/".$file_name;
        }
      
     $names =$_POST['name'];
     $district=$_POST['district'];
     $hallname =$_POST['hall'];
     $details =$_POST['details'];
     
  $sql="INSERT INTO new_event (eventname,district,hallname,eventdetails,filenames)
   VALUES('$names','$district','$hallname','$details',\"$names\")"; 
   $q3=$conn->query($sql) or trigger_error($conn->error);
     //$result=mysqli_query($conn,$sql);
     if ($q3) {
        echo "new record inserted";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
      //closing connection
     mysqli_close($conn);

    }
?>
<html>


<body>

<div id="content" possition="center">
        <form  action="" method="POST" enctype="multipart/form-data">
       <input type="text" name="name" placeholder="eventname" ><br>
        <input type="text" name="district" placeholder="district" ><br>
        <input type="text" name="hall" placeholder="hallname" ><br>
        <textarea name="details" placeholder="details"  rows="7" cols="40" style="width:100%;max-width:350px;"></textarea>
        <br>
       <input type="file" 
                   name="image" 
                   value="" />
  
            <div>
                <button type="submit"
                        name="upload">
                  UPLOAD
                </button>
            </div>
        </form>
</div>




</body>
</html>