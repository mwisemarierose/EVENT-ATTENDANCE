<?php
$conn= mysqli_connect('localhost','rose','ikinyogote','event attendance');
//check for connection
if(!$conn){
    echo 'connection error:'. mysqli_connect_error();

}
else{
    echo '';
}
?>
<?php
$sql='SELECT eventname,district,eventdetails,hallname,filenames FROM new_event';

//$sql= mysql_query("SELECT id,fname,lname,email,sex,age,created_at FROM  users", $conn);
//query for result
$result=mysqli_query($conn,$sql);
//query to fetch results
$dsply=mysqli_fetch_all($result,MYSQLI_ASSOC) or trigger_error($conn->error);
//$dsply=$conn->query($sql) or trigger_error($conn->error);
//print_r($login);

?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>event</title>
  <style>
  body {
    
    margin:1px;
  }

div.polaroid {
  width: 60%;
  background-color: none;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  margin-bottom: 25px;
  display:flex;
  grid-gap:20px;
}
div.polaroid img {
  border: 1px solid #ddd;
  border-radius: 9px;
  padding: 5px;
 height: 60%;
  width: 50%;
  font: left;
}
div.polaroid button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  border-radius: 16px;
}
div.polaroid button a {
    text-decoration: none;
}

  </style>



  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body >
  <!-- ======================= Header================= -->
 
  <header>
    <nav class="nav-menu">
      <ul >
        <li><a href="home.php">Home</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="gallery.php">Gallery</a></li>
        <li><a href="login.php">LOGIN</a></li>
      </ul>
    </nav>
  </header>
  <div  class="slider">
  <img src="./images/hh.jpg"width="100%" height="85%">
    </div>
  <?php foreach($dsply as $dsply): ?> 
    <div class="polaroid"><img src="<?php echo htmlspecialchars($dsply['filenames'])?>"style ="border: 1px solid #ddd;"> <br/>
        <b>EVENT NAME:<?php echo htmlspecialchars($dsply['eventname'])?> <br>
        <b>DISTRICT: <?php echo htmlspecialchars($dsply['district'])?> </b><br/>
        <b> HALL NAME: <?php echo htmlspecialchars($dsply['hallname'])?> </b><br>
        DETAILS: <?php echo htmlspecialchars($dsply['eventdetails'])?> <br>
        </p>
       <button> <a href="login.php" onmouseover="mousover1(this)" onmouseout="mousout1(this)">JOIN</a></button>
        </div>                
     <?php endforeach; ?>
        </div>
        </div> 
        </div>
<!-- ================================== Section Home============== -->
<br>
<center>
<footer >
  <p >KIGALI/RWANDA</p>
  </center>
</body>
</html>