-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2021 at 11:45 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `event attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `names` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `festival` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(10) NOT NULL,
  `eventname` varchar(255) NOT NULL,
  `filenames` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `eventname`, `filenames`) VALUES
(0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `new_event`
--

CREATE TABLE `new_event` (
  `eventid` int(5) NOT NULL,
  `eventname` varchar(255) NOT NULL,
  `eventdetails` text NOT NULL,
  `district` varchar(255) NOT NULL,
  `hallname` varchar(255) NOT NULL,
  `filenames` varchar(255) NOT NULL,
  `created_` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `new_event`
--

INSERT INTO `new_event` (`eventid`, `eventname`, `eventdetails`, `district`, `hallname`, `filenames`, `created_`) VALUES
(8, 'umuganura festival', 'Umuganura is a Rwandan harvest festival celebrated on the first Friday in August.\r\n         It is a public holiday that celebrates the country’s cultural heritage, \r\n         as well as its achievements in various sectors of the economy.\r\n         The roots of the Umuganura festival can be traced back to pre-colonial times. \r\n        The name of the festival can be translated from Kinyarwanda as “first fruits festival”.\r\n       In Rwandan culture, it was prohibited for a family to eat the fruits of the new harvest before having their elders taste them.\r\n       So Umuganura was about dedicating the first fruit to the family’s ancestors. \r\n       It was the day of feasting and giving thanks to the ancestors and the God', 'kicukiro', 'hall1', 'images/rda.jpg', '2021-08-05 19:28:55'),
(11, 'mashirika theater', 'Africa’s Hope is a story of survival and hope, \r\nIt is the Rwandan genocide against the tusti through the eye of a child,\r\na constant work in progress that has evolved tremendously since its first staging 2004 with a cast of over 1,000 people ,\r\nthe piece speaks to the beast that lives inside of everyone and questions the circumstances that cause that beast to be unleashed.\r\n The emotional difficulties and lingering traumas post-1994 do not outweigh the importance of telling the story;', 'muhanga', 'st Andre', 'images/hope.jpg', '2021-08-05 19:52:44'),
(17, 'seka live festival', 'Arthur Nation, the organisers of the Seka Live comedy series, is bringing the Kids’ Summer Festival to Kigali this weekend.\r\nThe two-day event is slated for Saturday and Sunday at the Spiderman Game Centre in Masaka. The centre is renowned for hosting interactive children’s events like the Christmas Kids Festival and Easter Kids Party.\r\n\r\n\r\n', 'nyarugenge', 'kigali arena', 'seka live festival', '2021-08-05 20:10:10');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `names` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `locations` varchar(255) DEFAULT NULL,
  `festival` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `names`, `email`, `phone`, `created_at`, `locations`, `festival`) VALUES
(1, 'yubahwe', 'mwisemarierose@gmail.com', 784534343, '2021-08-01 19:50:12', 'northern province', 'SP'),
(2, 'gaju', 'gaju@gmail', 786543232, '2021-08-01 19:51:47', 'northern province', 'HF'),
(3, 'yubahwe', 'mwisemarierose@gmail.com', 786543232, '2021-08-01 19:54:55', 'southern province', 'none'),
(4, 'rose', 'mwisemarierose@gmail.com', 786543232, '2021-08-01 19:57:12', 'southern province', 'mashirika festival'),
(5, 'yubahwe', 'mwisemarierose@gmail.com', 784534343, '2021-08-03 05:33:54', 'southern province', 'none'),
(6, 'yubahwe', 'mwisemarierose@gmail.com', 784534343, '2021-08-03 05:35:06', 'southern province', 'mashirika festival'),
(7, 'yubahwe', 'mwisemarierose@gmail.com', 786543232, '2021-08-03 08:15:30', 'eastern province', 'mashirika festival'),
(8, 'tyo', 'mwisemarierose@gmail.com', 784534343, '2021-08-03 19:52:20', 'eastern province', 'mashirika festival'),
(9, 'rose', 'munezeronadine01@gmail.com', 78888888, '2021-08-10 14:20:35', 'northern province', 'mashirika festival');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `passwords` varchar(255) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`fullname`, `username`, `email`, `passwords`, `id`) VALUES
('rose', 'rose11', 'mwisemarierose@gmail.com', '123', 1),
('eich', 'eich11', 'e@gmai.com', '123', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new_event`
--
ALTER TABLE `new_event`
  ADD PRIMARY KEY (`eventid`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `new_event`
--
ALTER TABLE `new_event`
  MODIFY `eventid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
