<?php
 include('db_connect.php');

if(isset($_POST['submit'])){
   
    $names =$_POST['name'];
    $phone =$_POST['PhoneNumber'];
    $email =$_POST['FromEmailAddress'];
    $comment =$_POST['comments'];
    $festival=$_POST['festival'];
    

 $sql="INSERT INTO contact(names,phone,email,comment,festival)
  VALUES('$names','$phone','$email','$comment','$festival')";

if(mysqli_query($conn,$sql)){
 header('Location:gallery.php');

}
else{

  echo 'query error: '.mysql_error($conn);
}

mysqli_close($conn);

}

?>
<!DOCTYPE html>
<html>
<head>
<title>
    Events | Contact
</title>
<style>
  .l:hover{
    background-color:darkcyan;
  }
</style>
<link rel="stylesheet" href="style.css">
</head>
<body style="background-image: url(./images/cover.jpg);">
    <header>
        <nav class="nav-menu">
          <ul >
            <li><a href="home.php">Home</a></li>
            
            <li><a href="contact.php">Contact</a></li>
            <li><a href="gallery.php">Gallery</a></li>
            <li><a href="login.php">LOGIN</a></li>
          </ul>
        </nav>
      </header>
    <section>
      <nav class="cont">
    <img src="./images/cont.jpg"width="600" height="150">
<p><u><b> DON'T HESITATE TO CALL US IF YOU HAVE ANY PROBLEM WE'RE HERE FOR YOU</b></U></P>
<form action="contact.php" id="ContactUs100" method="POST" onsubmit="return ValidateForm(this);">
<script type="text/javascript">
function ValidateForm(frm) {
if (frm.Name.value == "") { alert('Name is required.'); frm.Name.focus(); return false; }
if (frm.FromEmailAddress.value == "") { alert('Email address is required.'); frm.FromEmailAddress.focus(); return false; }
if (frm.FromEmailAddress.value.indexOf("@") < 1 || frm.FromEmailAddress.value.indexOf(".") < 1) { alert('Please enter a valid email address.'); frm.FromEmailAddress.focus(); return false; }
if (frm.Comments.value == "") { alert('Please enter comments or questions.'); frm.Comments.focus(); return false; }
return true; }
</script>
<table style="width:100%;max-width:550px;border:0;" cellpadding="8" cellspacing="0">
<tr> <td>
<label for="festival"><b>Festival</b></label>
</td><td><br>
<select id="list" name="festival">
<option value ="none">NONE</option>
<option value="umuganura festival">umuganura festival</OPTION>
<option value="mashirika theater">mashirika theater</OPTION>
<option value="seka live festival">seka live festival</OPTION>
</select><br>
</td> </tr>
<tr> <td>
<label for="Name">Name*:</label>
</td> <td><br>
<input name="Name" type="text" maxlength="60" style="width:100%;max-width:250px;" />
</td> </tr> <tr> <td>
<label for="PhoneNumber">Phone number:</label>
</td> <td></br>
<br><input name="PhoneNumber" type="text" maxlength="43" style="width:100%;max-width:250px;" />
</td> </tr> <tr> <td></br>
<br><label for="FromEmailAddress">Email address*:</label></br>
</td> <td>
<input name="FromEmailAddress" type="text" maxlength="90" style="width:100%;max-width:250px;padding: 10px;" />
</td> </tr> <tr> <td>
<br><label for="Comments">Comments*:</label></br>
</td> <td>
<textarea name="Comments" rows="7" cols="40" style="width:100%;max-width:350px;"></textarea>
</td> </tr> <tr> <td>
* - required fields
</td> <td><br>
<b><input class="l" name="Submit" type="submit" value="Submit"style="padding:5px" /></b>
</td> </tr>
</nav>
</table>
</form>
</section>
</body>
</html>