<?php
 include('db_connect.php');

if(isset($_POST['submit'])){
  
    $names =$_POST['name'];
    $email =$_POST['email'];
    $phone =$_POST['psw'];
    $locations =$_POST['province'];
    $festival =$_POST['festival'];

 $sql="INSERT INTO register(names,email,phone,locations,festival)
  VALUES('$names','$email','$phone','$locations','$festival')";

if(mysqli_query($conn,$sql)){
 header('Location: home.php');

}
else{

  echo 'query error: '.mysql_error($conn);
}

mysqli_close($conn);

}
?>
<!DOCTYPE html>
<html>
    <head>
        <title> Event | register</title>
        <style>
 Body {  
      font-family: Calibri, Helvetica, sans-serif;  
      background-color:skyblue;  
    }  

* {
  box-sizing: border-box;
  padding: 16px;
  background-color:white ;
}


input[type=text]{
  width: 25%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
  align-content: center;

}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}
.button1 {
  background-color:green;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 25%;
  opacity: 0.9;
}

.button1:hover {
background-color:black;
}
.container{
  align-content:center ;
}

</style>   
<link rel ="stylesheet" href="style.css">
</head>
    <body>
        <header>
            <nav class="nav-menu">
              <ul >
                <li><a href="#">Home</a></li>
        
                <li><a href="contact.php">Contact</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="login.php">LOGIN</a></li>
              </ul>
            </nav>
           
          </header>
<section>
 <b></b> <h4 style=color:blue >****PLEASE FILL THE FORM BELOW****</h4></b>
  <br></br>
<form action="register.php" method="POST">

<label for="festival"><b>Festival</b></label>
<select id="list" name="festival">
<option value ="none">NONE</option>
<option value="mashirika festival">MASHIRIKA FESTIVAL</OPTION>
<option value="harvest festival">HARVEST FEASTIVAL</OPTION></select><hr>
    <div class="container">
      <h1>Registration form</h1>
      <hr>
      <label for="name"><b>NAMES:</b></label><br>
      <input type="text" placeholder="Enter your name" name="name" id="name" required>
      <label for="email"><b>Email</b></label>
      <input type="text" placeholder="Enter Email" name="email" id="email" required>
      <label for="psw"><b>phone number</b></label>
      <input type="text" placeholder="Enter your phone number" name="psw" id="psw" required>
      <label for="location"><b>locations </b></label>
      <select id="province" name="province" required>
        <option style="padding: 30px;" value="southern province">Southern province</option>
        <option value="northern province">Northern province</option>
        <option value="western province">Western province</option>
        <option value="eastern province">Eastern province</option>
        <option value="kigali city">Kigali city</option>
      </select>
      <hr>
      <button type="submit" name="submit" class="button button1" style="color:honeydew; padding:15px;margin:10px;">Register</button>
    </div>
</form>
</section>
</body>
</html>